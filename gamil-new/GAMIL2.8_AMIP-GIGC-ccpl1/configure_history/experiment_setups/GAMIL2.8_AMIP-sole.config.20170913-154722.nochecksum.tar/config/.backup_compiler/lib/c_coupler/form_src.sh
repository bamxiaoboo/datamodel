#!/bin/bash

Env=$1
Srclist=$3

source $Env

touch $Srclist
cat > $Srclist << EOF
$CODEROOT/libs/c_coupler/CoR
$CODEROOT/libs/c_coupler/Data_MGT
$CODEROOT/libs/c_coupler/Driver
$CODEROOT/libs/c_coupler/Parallel_MGT
$CODEROOT/libs/c_coupler/Runtime_MGT
$CODEROOT/libs/c_coupler/Utils
EOF

exit 0
