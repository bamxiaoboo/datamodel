#! /bin/csh -f
##################################################################################
#  Copyright (c) 2013, Tsinghua University. 
#  This code is initially finished by Dr. Li Liu on 2013/3/21. 
#  If you have any problem, please contact:
#  Dr. Li Liu via liuli-cess@tsinghua.edu.cn
##################################################################################



link_data "$DATAROOT/cpl/remap_weights_files/remap_weights_files_by_SCRIP/map_licomeq1x1_to_gamil128x60_aave_091022.nc" "$RUN_ALL_DIR/remap_weights_files/remap_weights_files_by_SCRIP/"

