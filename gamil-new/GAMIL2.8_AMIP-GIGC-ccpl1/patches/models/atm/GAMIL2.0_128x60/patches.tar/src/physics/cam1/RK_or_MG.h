 
  character(len=2)  RK_or_MG
  parameter (RK_or_MG='MG')

