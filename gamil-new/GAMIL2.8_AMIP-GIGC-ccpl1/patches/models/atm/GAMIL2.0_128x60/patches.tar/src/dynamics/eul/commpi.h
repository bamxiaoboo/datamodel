
        
      integer nprocs, myrank, ierr, itop, ibot, jbeg, jend, jpole,nyend
      logical inc_pole

      common/commpi/ nprocs, myrank, itop, ibot, jbeg, jend, jpole, inc_pole,nyend
