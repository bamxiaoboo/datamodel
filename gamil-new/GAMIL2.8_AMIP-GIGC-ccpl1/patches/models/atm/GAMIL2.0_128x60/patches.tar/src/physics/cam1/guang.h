      common /guang/a,b,eps1,c1,c2,c3,tfreez
      real(r8) a
      real(r8) b
      real(r8) eps1
      real(r8) c1
      real(r8) c2
      real(r8) c3
      real(r8) tfreez
 
