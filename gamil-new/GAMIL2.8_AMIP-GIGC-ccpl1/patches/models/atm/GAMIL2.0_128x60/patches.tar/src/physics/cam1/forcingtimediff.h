integer timediff
parameter (timediff = 0)
