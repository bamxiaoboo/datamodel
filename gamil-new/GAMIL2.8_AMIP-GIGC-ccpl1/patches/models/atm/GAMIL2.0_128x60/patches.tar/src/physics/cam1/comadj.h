!
! $Id: comadj.h,v 1.6 2001/08/10 22:07:55 boville Exp $
! $Author: boville $
!
!
! Convective adjustment
!
      common/comadj/ nlvdry
!
      integer nlvdry        ! Number of levels to apply dry adjustment
!

 
