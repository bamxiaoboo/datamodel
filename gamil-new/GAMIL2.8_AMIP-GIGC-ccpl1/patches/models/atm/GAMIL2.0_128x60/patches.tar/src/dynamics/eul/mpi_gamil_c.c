
void is_the_same_array_(double* array1, double* array2, int *match_result)
{
    if (array1 == array2)
        *match_result = 1;
    else *match_result = 0;
}
