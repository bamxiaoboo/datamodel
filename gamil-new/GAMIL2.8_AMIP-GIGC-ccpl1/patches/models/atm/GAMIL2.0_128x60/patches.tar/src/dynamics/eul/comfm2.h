
!! (wanhui 2003.07.07)
!! (wanhui 2003.11.04)
!! (b.wang 2004.02.15)




!       real*8  up  (nx,ny,nl)  !
!       real*8  vp  (nx,ny,nl)  !
!       real*8  ttp (nx,ny,nl)  ! variables at step n-1
!       real*8  pps (nx,ny)     !


       real*8  dlt1
       real*8  dlt2

!       real*8  cs0 (nx,ny)
!       real*8  cbs (NX,NY,NL)
!       integer nzad(ny)

       common/comfm2/ dlt1,dlt2
