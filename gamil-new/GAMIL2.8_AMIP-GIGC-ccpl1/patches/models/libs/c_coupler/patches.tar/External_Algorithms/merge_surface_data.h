#ifndef MERGE_SURFACE_DATA_H
#define MERGE_SURFACE_DATA_H

extern void reset_surface_data(void**, void**, int*);
extern void merge_one_kind_surface_data(void**, void**, int*);

#endif
